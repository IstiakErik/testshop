<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'معلومات اوبن كارت أي بي آي';

// Text
$_['text_success']     = 'تم التعديل !';
$_['text_signup']      = 'الرجاء ادخال معلومات اوبن كارت أي بي آي والذي يمكنك الحصول عليه من <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">الرابط التالي</a>.';

// Entry
$_['entry_username']   = 'اسم المستخدم';
$_['entry_secret']     = 'كلمة السر';

// Error
$_['error_permission'] = 'تحذير  : أنت لا تمتلك صلاحيات التعديل!';
$_['error_username']   = 'مطلوب !';
$_['error_secret']     = 'مطلوب !';
