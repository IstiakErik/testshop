<?php
// Heading
$_['heading_title']    = 'النشرات الإخبارية';

// Text
$_['text_extension']   = 'ملحقات';
$_['text_success']     = 'النجاح: لقد قمت بتعديل النشرات الإخبارية!';
$_['text_edit']        = 'تحرير النشرات الإخبارية الوحدة';

// Entry
$_['entry_status']     = 'الحالة';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن بتعديل وحدة النشرات الإخبارية!';
