<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']  = '%s - رصيد نظام العمولة';
$_['text_received'] = 'لقد استلمت %s كرصيد في المتجر !';
$_['text_total']    = 'رصيدك الإجمالي حالياً هو %s.';
$_['text_credit']   = 'يمكنك اسخدام رصيدك بدءً من العملية الشرائية التالية.';
