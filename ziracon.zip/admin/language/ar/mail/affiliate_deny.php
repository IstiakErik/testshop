<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject'] = '%s - تم رفض تفعيل حسابك في برنامج نظام العمولة !';
$_['text_welcome'] = 'شكراً لتسجيلك في %s !';
$_['text_denied']  = 'للأسف تم رفض طلبك. ولمزيد من الاستفسارات يمكنك التواصل مع إدارة المتجر من خلال الرابط التالي :';
$_['text_thanks']  = 'شكراً لك,';
